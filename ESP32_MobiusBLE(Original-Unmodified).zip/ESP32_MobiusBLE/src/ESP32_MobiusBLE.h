/*!
 * This file defines the ESP32_MobiusBLE library.
 */

#ifndef _ESP32_MOBIUS_BLE_H_
#define _ESP32_MOBIUS_BLE_H_

#include "MobiusCRC.h"
#include "MobiusDevice.h"

#endif
